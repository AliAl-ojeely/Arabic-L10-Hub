Have a Nice Death - Arabic Localization
======================================

Arabic localization version: v1.0.0
Supported game version: v1.0.4.55150
Translation and proofreading: Ali Al-Ojeely
Project: Arabic L10 Hub

Manual installation
-------------------
1. Close the game.
2. Open the game folder.
3. Back up:
   HaveaNiceDeath_Data\resources.assets
4. Copy the included:
   HaveaNiceDeath_Data
   folder into the game root.
5. Confirm replacement of resources.assets.
6. Launch the game normally through Steam.

Uninstall
---------
Restore your original resources.assets backup, or use Steam's
Verify Integrity of Game Files.

Supported original resources.assets SHA256:
0569edae1466e01b1ccf45296eaa265646e30d41a19e220c20561e75df2a63d5

Arabic resources.assets SHA256:
31bf51d8dba7abad46e49a8d42c7a018ac373e385386e0906b6d5e3a5b7145dc

This package contains no BAT, PowerShell, EXE, BepInEx, or runtime hooks.
Only resources.assets is replaced.
